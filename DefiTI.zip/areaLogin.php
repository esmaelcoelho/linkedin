<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="linkStyle" rel="stylesheet" href="css/style.css">
    <link id="menuStyle" rel="stylesheet" href="css/stylemenu.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <script src="script.js" defer ></script>  
    <title>Login</title>
</head>

<body id="areaLogin">
  <div id="top"></div>
    <div class="content03">
        <?php
        include ('menu.php');
        ?>
            
        <div class="container3-0">
            <h1>Área de login</h1>
            <h2>Bem-vindo de volta!</h2>
            <div class="container3-1">
                <form action="#" method="POST">
                    <div class="conjunto">

                        <div>
                            <label for="">E-mail </label>
                            <input size="40" type="email" name="ds_emailEmpresa" required autocomplete="off">
                        </div>

                        <div>
                            <label for="ds_senha">Senha</label>
                            <input size="40" type="password" name="ds_senha" required>
                        </div>

                        <div class="check">
                            <div class="check1">
                                <input type="checkbox" checked>
                                <span>Mantenha-me logado</span>
                            </div>
                            <div class="check2">
                                <a href="">Esqueci a senha</a>
                            </div>
                        </div>

                        <div class="button">
                            <button class="bt" type="submit" id="submit" value="Enviar">Entrar</button>
                        </div>

                        <div id="bottom">
                            <span class="sub1">Ainda não criou uma conta?</span>
                            <span class="sub2">Cadastre-se como <a href="cadastroCandidato.php" style="font-weight: 600;">Candidato </a>ou <a
                                    href="cadastroEmpresa.php" style="font-weight: 600;">Empresa/Recrutador</a></span>
                        </div>
                </form>
            </div>
        </div>
    </div>
    </div>
    <a href="#top" class="top"><img src="img/top.svg">Topo</a>
    <?php
      include ('footer.php');
    ?>

</body>

</html>