<?php
try 
{
	$conexao = new PDO("mysql:host=localhost;dbname=id16393955_defiti",
                   "id16393955_defit", "p4UErAbs9Za3=f%8");
	$conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} 
catch(PDOException $e) 
{
    echo 'ERRO: ' . $e->getMessage();
}
?>