<?php

	include_once'conexao.php';

  $empresa = $_POST['empresa'];
  $email = $_POST['email'];
  $senha = md5($_POST['senha']);
  $cnpj = $_POST['cnpj'];
  $representante = $_POST['representante'];
  $telefone = $_POST['telefone'];
  $cargo = $_POST['cargo'];
  
  try{
    
	$stmt = $conexao->prepare("INSERT INTO tb_empresa(nm_empresa,
	                                               ds_emailEmpresa, 
												   ds_senha, 
												   nu_cnpj,
												   nm_representante,
												   nu_telefone,
												   ds_cargo)
					        VALUES(?,?,?,?,?,?,?)");
	
	$stmt->bindParam(1,$empresa);
	$stmt->bindParam(2,$email);
	$stmt->bindParam(3,$senha);
	$stmt->bindParam(4,$cnpj);
	$stmt->bindParam(5,$representante);
	$stmt->bindParam(6,$telefone);
	$stmt->bindParam(7,$cargo);
	
	
	$stmt->execute();
	
	echo "<script> alert('Cadastrado com sucesso');</script>";
	echo "<script> window.location.href='cadastroEmpresa.php'</script>";
	}
	catch(PDOException $e) 
	{
		echo 'ERRO: ' . $e->getMessage();
	}

?>