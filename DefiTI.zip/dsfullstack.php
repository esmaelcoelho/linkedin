<!DOCTYPE html>
<html lang="pt-br">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="linkStyle" rel="stylesheet" href="css/style.css">
    <link id="menuStyle" rel="stylesheet" href="css/stylemenu.css">
    <link rel="stylesheet" rel="stylesheet" href="bootstrap-5.0.0-beta3-dist/css/bootstrap.min.css">
    <script src="bootstrap-5.0.0-beta3-dist/js/bootstrap.min.js"></script>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <script src="script.js" defer ></script> 
    <title>Fullstack</title>
</head>

<body>
    <div class="content06">
        <?php 
            include ('menu.php');
        ?>

        <div id="fundo">
            <div id="buscaVaga">
                <input type="text" id="txtBusca" placeholder="Pesquisar Serviço" />
                <img src="img/search.svg" id="buscar" alt="Buscar" />
            </div>
            <div id="buscaEstado">
                <select name="estado" id="selEst">
                    <option selected="" value="">Selecione o Estado (UF)</option>
                    <option value="AC">Acre</option>
                    <option value="AL">Alagoas</option>
                    <option value="AP">Amapá</option>
                    <option value="AM">Amazonas</option>
                    <option value="BA">Bahia</option>
                    <option value="CE">Ceará</option>
                    <option value="DF">Distrito Federal</option>
                    <option value="ES">Espírito Santo</option>
                    <option value="GO">Goiás</option>
                    <option value="MA">Maranhão</option>
                    <option value="MT">Mato Grosso</option>
                    <option value="MS">Mato Grosso do Sul</option>
                    <option value="MG">Minas Gerais</option>
                    <option value="PA">Pará</option>
                    <option value="PB">Paraíba</option>
                    <option value="PR">Paraná</option>
                    <option value="PE">Pernambuco</option>
                    <option value="PI">Piauí</option>
                    <option value="RJ">Rio de Janeiro</option>
                    <option value="RN">Rio Grande do Norte</option>
                    <option value="RS">Rio Grande do Sul</option>
                    <option value="RO">Rondônia</option>
                    <option value="RR">Roraima</option>
                    <option value="SC">Santa Catarina</option>
                    <option value="SP">São Paulo</option>
                    <option value="SE">Sergipe</option>
                    <option value="TO">Tocantins</option>
                </select>
            </div>
            <div id="Procurar"><button>Procurar</button></div>
        </div>

        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="navg">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="servicos.php">Serviços</a></li>
              <li class="breadcrumb-item active" aria-current="page">Fullstack</li>
            </ol>
          </nav>

        <section class="corpoServ">
            <header>
                <h2>Fullstack</h2>
                <h3>Conheça os nossos melhores desenvolvedores fullstack!</h3>
            </header>

            <article class="corpoProf">
                <div class="card" style="width: 20rem;">
                  <div class="card-body">
                    <h5 class="card-title">Lorrane de Cassia</h5>
                    <h6 class="card-title">Desenvolvedor Web</h6>

                    <hr> 

                    <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque eligendi voluptatem doloribus temporibus repellat perspiciatis consectetur eos adipisci accusamus? Nesciunt officiis doloribus minima quis alias mollitia obcaecati praesentium eaque perspiciatis.</p>
                    <a href="#" class="btn btn-outline-primary">Contatar</a>
                  </div>
                </div>

                <div class="card" style="width: 20rem;">
                    <div class="card-body">
                      <h5 class="card-title">Jade Veríssimo</h5>
                      <h6 class="card-title">Desenvolvedor Web</h6>
  
                      <hr> 
  
                      <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque eligendi voluptatem doloribus temporibus repellat perspiciatis consectetur eos adipisci accusamus? Nesciunt officiis doloribus minima quis alias mollitia obcaecati praesentium eaque perspiciatis.</p>
                      <a href="#" class="btn btn-outline-primary">Contatar</a>
                    </div>
                  </div>

                  <div class="card" style="width: 20rem;">
                    <div class="card-body">
                      <h5 class="card-title">Edison Junior</h5>
                      <h6 class="card-title">Programador</h6>
  
                      <hr> 
  
                      <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque eligendi voluptatem doloribus temporibus repellat perspiciatis consectetur eos adipisci accusamus? Nesciunt officiis doloribus minima quis alias mollitia obcaecati praesentium eaque perspiciatis.</p>
                      <a href="#" class="btn btn-outline-primary">Contatar</a>
                    </div>
                  </div>
                  </article>

                  <article class="corpoProf">
                      <div class="card" style="width: 20rem;">
                        <div class="card-body">
                          <h5 class="card-title">Esmael Coelho</h5>
                          <h6 class="card-title">Desenvolvedor Web</h6>
                          <hr>
                          <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque eligendi voluptatem doloribus temporibus repellat perspiciatis consectetur eos adipisci accusamus? Nesciunt officiis doloribus minima quis alias mollitia obcaecati praesentium eaque perspiciatis.</p>
                          <a href="#" class="btn btn-outline-primary">Contatar</a>
                        </div>
                      </div>

                      <div class="card" style="width: 20rem;">
                        <div class="card-body">
                          <h5 class="card-title">Guilherme Ferreira</h5>
                          <h6 class="card-title">Desenvolvedor Web</h6>
                          <hr>
                          <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque eligendi voluptatem doloribus temporibus repellat perspiciatis consectetur eos adipisci accusamus? Nesciunt officiis doloribus minima quis alias mollitia obcaecati praesentium eaque perspiciatis.</p>
                          <a href="#" class="btn btn-outline-primary">Contatar</a>
                        </div>
                      </div>

                      <div class="card" style="width: 20rem;">
                        <div class="card-body">
                          <h5 class="card-title">Marcos Roberto</h5>
                          <h6 class="card-title">Desenvolvedor Web</h6>
                          <hr>
                          <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque eligendi voluptatem doloribus temporibus repellat perspiciatis consectetur eos adipisci accusamus? Nesciunt officiis doloribus minima quis alias mollitia obcaecati praesentium eaque perspiciatis.</p>
                          <a href="#" class="btn btn-outline-primary">Contatar</a>
                        </div>
                      </div>
                  </article>
            </article>
        </section>

    </div>

    <?php
      include ('footer.php');
    ?>

    <script src="https://kit.fontawesome.com/1ab94d0eba.js" crossorigin="anonymous"></script>
</body>
</html>