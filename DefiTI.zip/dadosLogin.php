<?php
    session_start();
    include_once'./conexao.php';
    
        $email = $_POST['ds_emailEmpresa'];
        $senha = md5($_POST['ds_senha']);
        $sql = $conexao->prepare("SELECT * FROM tb_candidato WHERE ds_email = '$email' AND ds_senha = '$senha'");
        $sql->execute([$email,$senha]);
        if($sql->rowCount() == 1){
            echo "<script> alert('Bem Vindo. Que bom que voltou!');</script>";
            echo "<script> window.location.href='index.php'</script>";
            $info = $sql->fetch();
        }else{
            echo "<script> alert('Usuário não encontrado.');</script>";
	        echo "<script> window.location.href='areaLogin.php'</script>";
        }
?>