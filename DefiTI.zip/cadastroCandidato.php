<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="linkStyle" rel="stylesheet" href="css/style.css">
    <link id="menuStyle" rel="stylesheet" href="css/stylemenu.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <script src="script.js" defer ></script> 
    <title>Cadastro de Candidato</title>
</head>

<body id="cadastroCandidato">
    <div id="top"></div>
    <div class="content02">
        <!-- MENU -->
        <?php
        include ('menu.php');
        ?>
        <!-- /MENU -->
        <div class="container2-0">
            <h1>CADASTRO DE CANDIDATO</h1>
            <h2>Seu emprego está aqui!</h2>
            <div class="container2-1">
                <form action="dadosCandidato.php" method="POST">
                    <div class="conjunto">
                        <div>
                            <label for="candidato">Nome</label>
                            <input type="text" name="candidato" required autocomplete="off">
                        </div>

                        <div>
                            <label for="email">E-mail</label>
                            <input type="email" name="email" required autocomplete="off">
                        </div>

                        <div>
                            <label for="senha">Senha</label>
                            <input type="password" name="senha" required>
                        </div>

                        <div>
                            <label for="cep">CEP</label></br>
                            <input type="number" name="cep" required autocomplete="off">
                        </div>

                        <div>
                            <label for="cargo">Cargo Desejado</label>
                            <input type="text" name="cargo" required>
                        </div>

                        <div>
                            <label for="deficiencia">Tipo de Deficiencia</label>
                            <input type="text" name="deficiencia" required autocomplete="off">
                        </div>

                        <div>
                            <label for="cid">Número do CID <span style="opacity: 0.5;">(opcional)</span></label>
                            <input type="text" name="cid" autocomplete="off">
                        </div>

                        <div class="button">
                            <button class="bt" type="submit" id="submit" value="Enviar">Cadastrar</button>
                        </div>

                        <!--<div>
                            <label class="sub">Você é uma empresa? <a href="cadastroEmpresa.php">Cadastre-se
                                    aqui!</a></label>
                        </div>-->

                    </div>
                </form>
            </div>
        </div>
    </div>
    <a href="#top" class="top"><img src="img/top.svg">Topo</a>
    <?php
      include ('footer.php');
    ?>

</body>

</html>