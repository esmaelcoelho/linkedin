<?php

	include_once'conexao.php';

  $candidato = $_POST['candidato'];
  $email = $_POST['email'];
  $senha = md5($_POST['senha']);
  $cep = $_POST['cep'];
  $cargo = $_POST['cargo'];
  $deficiencia = $_POST['deficiencia'];
  $cid = $_POST['cid'];
  
  try{
    
	$stmt = $conexao->prepare("INSERT INTO tb_candidato(nm_candidato,
	                                               ds_email, 
												   ds_senha, 
												   nu_cep,
												   ds_cargo,
												   ds_deficiencia,
												   nu_cid)
					        VALUES(?,?,?,?,?,?,?)");
	
	$stmt->bindParam(1,$candidato);
	$stmt->bindParam(2,$email);
	$stmt->bindParam(3,$senha);
	$stmt->bindParam(4,$cep);
	$stmt->bindParam(5,$cargo);
	$stmt->bindParam(6,$deficiencia);
	$stmt->bindParam(7,$cid);
	
	
	$stmt->execute();
	
	echo "<script> alert('Cadastrado com sucesso');</script>";
	echo "<script> window.location.href='cadastroCandidato.php'</script>";
	}
	catch(PDOException $e) 
	{
		echo 'ERRO: ' . $e->getMessage();
	}

?>