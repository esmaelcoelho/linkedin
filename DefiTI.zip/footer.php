<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.0-beta3-dist/css/bootstrap.min.css">
    <link id="footer" rel="stylesheet" href="css/footer.css">
    <script src="script.js" defer></script>
    <title>Footer</title>
</head>
<body>
    <footer id="myFooter">
        <div class="row">
            <div class="col-sm-3">
                <h2 class="logo"><a href="index.html"> DEFITI </a></h2>
            </div>
            <div class="col-sm-2">
                <h5>Inicio</h5>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="vagas.html">Vagas</a></li>
                    <li><a href="leis.html">Leis</a></li>
                </ul>
            </div>
            <div class="col-sm-2">
                <h5>Sobre-nós</h5>
                <ul>
                    <li><a href="sobreNos.html">Informações da Equipe</a></li>
                    <li><a href="contato.html">Contato</a></li>
                </ul>
            </div>
            <div class="col-sm-2">
                <h5>Suporte</h5>
                <ul>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Telefones</a></li>
                    <li><a href="#">E-mail</a></li>
                </ul>
            </div>
            <div class="col-sm-3">
                <div class="social-networks">
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
                </div>
                <a href="#">
                    <button type="button" class="btn btn-default"><a href="cadastroEmpresa.html">Cadastre-se</a></button>
                </a>
            </div>
        </div>
        </div>
        <div class="footer-copyright">
            <p>© 2021 Copyright - DefiTI</p>
        </div>
    </footer>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="bootstrap-5.0.0-beta3-dist/js/bootstrap.min.js"></script>
	<script src="https://kit.fontawesome.com/1ab94d0eba.js" crossorigin="anonymous"></script>
</body>
</html>