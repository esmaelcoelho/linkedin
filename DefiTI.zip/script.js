
var tema = localStorage.getItem("tema");
var zoom = localStorage.getItem("zoom");
if (tema) {
  trocarTema(tema);
}
if (zoom) {
  trocarZoom(zoom);
}

selecionarMenu();



function trocarTema(tema) {

  let link = document.getElementById("linkStyle");
  let menu = document.getElementById("menuStyle");
  let footer = document.getElementById("footer");
  let logo = document.getElementById("logo");
  let eye = document.getElementById("eye");
  let target = document.getElementById("target");
  let star = document.getElementById("star");

  if (tema === "preto") {
    link.href = "css/style-preto.css";
    menu.href = "css/stylemenu-preto.css";
    footer.href = "css/footer-preto.css";
    logo.src = 'img/logoBranco.png';
    if(eye){
      eye.src = 'img/eye1.svg';
    }
    if(target){
      target.src = 'img/target.svg';
    }
    if(star){
      star.src = 'img/star.svg';
    }
   

  } else if (tema === "default") {
    link.href = "css/style.css";
    menu.href = "css/stylemenu.css";
    footer.href = "css/footer.css";
    logo.src = 'img/Defiti Logo 02 transp2.png';
     if(eye){
      eye.src = 'img/eye1.svg';
    }
    if(target){
      target.src = 'img/target.svg';
    }
    if(star){
      star.src = 'img/star.svg';
    }

  } else if (tema === "branco") {
    link.href = "css/style-branco.css";
    menu.href = "css/stylemenu-branco.css";
    footer.href = "css/footer-branco.css";
    logo.src = 'img/Defiti Logo 02 transp2.png';
		if(eye) {
    	eye.src = 'img/eye2.svg';
		}
    if(target){
      target.src = 'img/target1.svg';
    }
    if(star){
      star.src = 'img/star1.svg';
    }
  }
  
  localStorage.setItem("tema", tema);
}

function trocarZoom(zoom) {
  let body = document.getElementsByTagName("body");
  for (let i = 0; i < body.length; i++) {
    body[i].style.zoom = zoom;
  }
  localStorage.setItem("zoom", zoom);
}

function maisZoom() {
  let zoomAtual = 1;

  if (localStorage.getItem("zoom")) {
    zoomAtual = localStorage.getItem("zoom");
  }
  zoomAtual = parseFloat(zoomAtual) + 0.1;
  trocarZoom(zoomAtual);

}

function menosZoom() {
  let zoomAtual = 1;

  if (localStorage.getItem("zoom")) {
    zoomAtual = localStorage.getItem("zoom");
  }
  zoomAtual = parseFloat(zoomAtual) - 0.1;
  trocarZoom(zoomAtual);
}

function selecionarMenu(){
  let path = window.location.pathname;
  let elemA = document.querySelector(`.opcoes-menu[data-url='${path}'] a`);
  if(elemA){
    elemA.classList.add("menu-selecionado");
  }

}