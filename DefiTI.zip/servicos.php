<!DOCTYPE html>
<html lang="pt-br">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="linkStyle" rel="stylesheet" href="css/style.css">
    <link id="menuStyle" rel="stylesheet" href="css/stylemenu.css">
    <link rel="stylesheet" rel="stylesheet" href="bootstrap-5.0.0-beta3-dist/css/bootstrap.min.css">
    <script src="bootstrap-5.0.0-beta3-dist/js/bootstrap.min.js"></script>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <script src="script.js" defer></script> 
    <title>Serviços</title>
</head>

<body >
    <div id="top"></div>
    <div class="content04">
        <?php
            include ('menu.php');
        ?>

        <div id="fundo">
            <div id="buscaVaga">
                <input type="text" id="txtBusca" placeholder="Pesquisar Serviço" />
                <img src="img/search.svg" id="buscar" alt="Buscar" />
            </div>
            <div id="buscaEstado">
                <select name="estado" id="selEst">
                    <option selected="" value="">Selecione o Estado (UF)</option>
                    <option value="AC">Acre</option>
                    <option value="AL">Alagoas</option>
                    <option value="AP">Amapá</option>
                    <option value="AM">Amazonas</option>
                    <option value="BA">Bahia</option>
                    <option value="CE">Ceará</option>
                    <option value="DF">Distrito Federal</option>
                    <option value="ES">Espírito Santo</option>
                    <option value="GO">Goiás</option>
                    <option value="MA">Maranhão</option>
                    <option value="MT">Mato Grosso</option>
                    <option value="MS">Mato Grosso do Sul</option>
                    <option value="MG">Minas Gerais</option>
                    <option value="PA">Pará</option>
                    <option value="PB">Paraíba</option>
                    <option value="PR">Paraná</option>
                    <option value="PE">Pernambuco</option>
                    <option value="PI">Piauí</option>
                    <option value="RJ">Rio de Janeiro</option>
                    <option value="RN">Rio Grande do Norte</option>
                    <option value="RS">Rio Grande do Sul</option>
                    <option value="RO">Rondônia</option>
                    <option value="RR">Roraima</option>
                    <option value="SC">Santa Catarina</option>
                    <option value="SP">São Paulo</option>
                    <option value="SE">Sergipe</option>
                    <option value="TO">Tocantins</option>
                </select>
            </div>
            <div id="Procurar"><button>Procurar</button></div>
        </div>

        
        <section class="corpoServ">
            <article id="servLinks">
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Desenvolvedor de aplicativo</a>
                        <span class="badge bg-primary rounded-pill">5</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Desenvolvedor front-end</a>
                        <span class="badge bg-primary rounded-pill">7</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="dsfullstack.php">Desenvolvedor fullstack</a>
                        <span class="badge bg-primary rounded-pill">6</span>
                    </li>
                </ul>

                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Programador</a>
                        <span class="badge bg-primary rounded-pill">24</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Analista de Sistemas</a>
                        <span class="badge bg-primary rounded-pill">2</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Engenheiro de Software</a>
                        <span class="badge bg-primary rounded-pill">8</span>
                    </li>
                </ul>
            </article>
            <article id="servLinks">
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Suporte Técnico</a>
                        <span class="badge bg-primary rounded-pill">16</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Banco de dados</a>
                        <span class="badge bg-primary rounded-pill">12</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Administração de redes</a>
                        <span class="badge bg-primary rounded-pill">27</span>
                    </li>
                </ul>

                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Segurança da informação</a>
                        <span class="badge bg-primary rounded-pill">6</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Office 365</a>
                        <span class="badge bg-primary rounded-pill">32</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="">Segurança da informação</a>
                        <span class="badge bg-primary rounded-pill">7</span>
                    </li>
                </ul>
            </article>
        </section>
    </div>
    <a href="#top" class="top"><img src="img/top.svg">Topo</a>
    <?php
      include ('footer.php');
    ?>

    <script src="https://kit.fontawesome.com/1ab94d0eba.js" crossorigin="anonymous"></script>
</body>
</html>