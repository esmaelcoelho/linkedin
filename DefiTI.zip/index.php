<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="linkStyle" rel="stylesheet" href="css/style.css">
    <link id="menuStyle" rel="stylesheet" href="css/stylemenu.css">
		<link rel="stylesheet" href="bootstrap-5.0.0-beta3-dist/css/bootstrap.min.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <script src="script.js" defer></script> 
    <title>Página Inicial</title>
</head>
<body id="paginaInicial" >
    <div id="top"></div>
    <div class="content01">
        <?php
        	include ('menu.php');
        ?>

        <header id="cabecalho-terc01">
            <h1>Defiti</h1>
            <h2>Todos <span style="font-weight: 600;">podem</span> e <span style="font-weight: 600;">precisam</span> ter uma oportunidade.</h2>
            <a href="areaLogin.php"><button id="login" class="bt">Entrar</button></a>
            <a href="cadastroEmpresa.php"><button id="inscrever" class="bt">Se Cadastrar</button></a>
        </header>

        <section id="apreset">
            <article id="cmc">
                <h1>Encontre o que você precisa, <br>
                    com quem você quer</h1>
                <h2>Em poucas palavras digite que tipo de serviço busca <br>
                e receba o melhor atendimento.</h2>
                <div id="busca">
                    <img src="img/search.svg" id="btnBusca" alt="Buscar"/>
                    <input type="text" id="txtBusca" placeholder="O que você precisa?"/>
                    <input type="submit" value="Buscar">
                </div>
                <img src="img/iconPeoples.svg" alt="" id="ilust">
            </article>

            <article id="aboutUs">
                <img src="img/Questions-pana.svg" id="duv"  alt="">
                <div id="textAbout">
                    <h3>Mas afinal...</h3>
                    <h4>O que é o DefiTI?</h4>
                    <p>Atualmente existem poucas vagas para PcD (Pessoa com Deficiência) no Brasil, o que torna a integração desses profissionais no mercado de trabalho muito mais difícil.</p> 
                    <p>Por este motivo, desenvolvemos esta plataforma online onde permite que pessoas com deficiência possam ser encontradas com mais facilidade, dando a elas uma oportunidade de trabalho. </p>
                </div>
            </article>

            <header id="titleSection">
                <h2>Sobre nós</h2>
                <h3>Conheça um pouco mais sobre nosso projeto!</h3>
            </header>

            <article id="cardsInfo">
                <div class="card" style="width: 18rem; height: 17rem;">
                    <img class="card-img-top" src="img/target.svg" alt="Card image cap" id="target">
                    <div class="card-body">
                        <h5 class="card-title">Missão</h5>
                        <p class="card-text">Promover e colaborar com a divulgação de profissionais PcD na área da tecnologia da informação.</p>
                    </div>
                </div>
            
                <div class="card" style="width: 18rem; height: 17rem;" id="foco">
                    <img class="card-img-top" src="img/eye1.svg" alt="Card image cap" id="eye">
                    <div class="card-body">
                        <h5 class="card-title">Visão</h5>
                        <p class="card-text">Ser referência no ramo tecnológico pela inclusão e exclusividade ao público PcD.</p>
                    </div>
                </div>

                <div class="card" style="width: 18rem;  height: 17rem;">
                    <img class="card-img-top" src="img/star.svg" alt="Card image cap" id="star">
                    <div class="card-body">
                        <h5 class="card-title">Valores</h5>
                        <p class="card-text">- Diversidade e inclusão; <br>
                        - Valorização das pessoas; <br>
                        - Respeito, <br>
                        - Zelo.</p>
                    </div>
                </div>
            </article>
        </section>
    </div>
    <a href="#top" class="top"><img src="img/top.svg">Topo</a>
    <?php
    	include ('footer.php');
    ?>

</body>
</html>