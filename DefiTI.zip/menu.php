
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link id="menuStyle" rel="stylesheet" href="css/stylemenu.css">
    <script src="script.js" defer></script>
    <title>Menu Topo</title>
</head>
<body>
        <nav id="opcoes-acessibilidade">
            <ul id="acess">
                <li id="contraste" class="acess">Contraste</li>
                <li><div id="default" onclick="trocarTema('default')" class="circles"></div></li>
                <li><div id="branco" onclick="trocarTema('branco')" class="circles"></div></li>
                <li><div id="preto" onclick="trocarTema('preto')" class="circles"></div></li>
                <li id="menos" onclick="menosZoom()" class="fonte acess">A-</li>
                <li id="mais"  onclick="maisZoom()" class="fonte acess">A+</li>
            </ul>
        </nav>
        <nav id="opcoes-geral">
            <a href="index.php"><img src="img/Defiti Logo 02 transp2.png" alt="Logo DefiTI" id="logo"></a>
            <ul id="allOpcoes">
                <li class="opcoes-menu" data-url="/index.php"><a
                 href="index.php">Início</a></li>
                <li class="opcoes-menu" data-url="/servicos.php"><a href="servicos.php">Serviços</a></li>
                <li class="opcoes-menu"data-url="/noticias.php"><a href="servicos.php">Notícias</a></li>
                <li class="opcoes-menu" id="lei"><a href="#">Lei de Cotas</a></li>
                <li class="opcoes-menu"><a href="paginaTeste.php">Contato</a></li>
                <li class="opcoes-menu"data-url="/areaLogin.php"id="login"><a href="areaLogin.php">Login</a></li>
                <li class="opcoes-menu" id="cadastro" data-url="/cadastroCandidato.php"><a href="cadastroCandidato.php">Cadastro</a></li>
            </ul>
        </nav>
</body>
</html>